from olsq.solve import OLSQ
