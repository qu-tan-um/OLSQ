from olsq.olsq_cirq.solve import OLSQ_cirq
